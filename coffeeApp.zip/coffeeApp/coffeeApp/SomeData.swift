//
//  SomeData.swift
//  coffeeApp
//
//  Created by Code Nation on 04/03/2019.
//  Copyright © 2019 Adam Corlett. All rights reserved.
//

import Foundation

final class SomeData{
    
    static func generateCoffeesData()->[Coffee]{
        return[
            Coffee(name:"Latte",store:"Starbucks",rating:5),
            Coffee(name:"Latte",store:"Costa",rating:3),
            Coffee(name:"Latte",store:"Nero",rating:2)
        ]
    }
}
