//
//  Coffee.swift
//  coffeeApp
//
//  Created by Code Nation on 04/03/2019.
//  Copyright © 2019 Adam Corlett. All rights reserved.
//

import Foundation

struct Coffee {
    var name: String
    var store: String
    var rating: Int
}


